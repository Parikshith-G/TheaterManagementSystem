package com.login.controller;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.login.dto.AuthDto;
import com.login.exception.InvalidCredentialException;
import com.login.exception.UserAlreadyPresentException;
import com.login.model.User;
import com.login.security.Jwtutil;
import com.login.service.CustomUserDetailsService;
import com.login.service.UserServiceImpl;

import jakarta.validation.Valid;

@RestController
@Validated
@RequestMapping("/api/user")
@CrossOrigin("*")
public class UserController {
	Logger logger = LoggerFactory.getLogger(UserController.class);

	@Autowired
	private UserServiceImpl userService;

	@Autowired
	private Jwtutil jwtutil;

	@Autowired
	private BCryptPasswordEncoder encoder;

	@PostMapping("/register")
	public ResponseEntity<Object> registerUser(@RequestBody @Valid User user) throws UserAlreadyPresentException {
		if (userService.registerUser(user)) {
			String p = encoder.encode(user.getPassword());
			user.setPassword(p);

			return generateResponse("Added successfully", HttpStatus.OK, user, "");
			
		} else {
			return generateResponse("SOmwthing went wrong", HttpStatus.INTERNAL_SERVER_ERROR, user, "");
		}
	}

	@PostMapping("/login")
	public ResponseEntity<Object> loginUser(@RequestBody @Valid AuthDto loginUser) throws InvalidCredentialException {
		System.err.println("here2");
		String p = encoder.encode(loginUser.getPassword());
		String token = userService.login(loginUser);
		loginUser.setPassword(p);

		return generateResponse("Login successful", HttpStatus.OK, loginUser, token);
	}

	@GetMapping("/validate")
	public ResponseEntity<String> validate(@RequestParam("token") String token) {
		jwtutil.validateToken(token);
		return ResponseEntity.ok("Token is valid");
	}

	private ResponseEntity<Object> generateResponse(String message, HttpStatus httpStatus, Object responseObj,
			String token) {
		Map<String, Object> map = new HashMap<>();
		map.put("Message", message);
		map.put("Status", httpStatus.value());
		map.put("Data", responseObj);
		map.put("Token", token);

		return new ResponseEntity<>(map, httpStatus);
	}

}
