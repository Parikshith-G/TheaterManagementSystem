package com.login.exception;

public class UserNotFoundException extends Exception {

	public UserNotFoundException(String str) {
		super(str);
	}
	

}
