package com.login.exception;

public class UserAlreadyPresentException extends Exception {

	public UserAlreadyPresentException(String str) {
		super(str);
	}
	
}
