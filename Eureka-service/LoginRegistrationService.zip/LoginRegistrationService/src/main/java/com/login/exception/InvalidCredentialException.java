package com.login.exception;

public class InvalidCredentialException extends Exception {
	public InvalidCredentialException(String str) {
		super(str);
	}
}
