package com.login.controller;

import com.login.dto.AuthDto;
import com.login.exception.InvalidCredentialException;
import com.login.exception.UserAlreadyPresentException;
import com.login.model.User;
import com.login.security.Jwtutil;
import com.login.service.UserServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

public class UserControllerTest {

	@Mock
	private UserServiceImpl userService;

	@Mock
	private Jwtutil jwtutil;

	@Mock
	private BCryptPasswordEncoder encoder;

	@InjectMocks
	private UserController userController;

	@BeforeEach
	void setUp() {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	void testRegisterUser_Success() throws UserAlreadyPresentException {
		// Given
		User user = new User(null, "John Doe", "john.doe@example.com", "password", "1234567890", "USER", null, null);

		when(userService.registerUser(any(User.class))).thenReturn(true);
		when(encoder.encode(user.getPassword())).thenReturn("encodedPassword");

		// When
		ResponseEntity<Object> response = userController.registerUser(user);

		// Then
		assertNotNull(response);
		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertNotNull(response.getBody());

		// 
	}

	@Test
	void testRegisterUser_Failure() throws UserAlreadyPresentException {
		// Given
		User user = new User(null, "John Doe", "john.doe@example.com", "password", "1234567890", "USER", null, null);

		when(userService.registerUser(any(User.class))).thenReturn(false);

		// When
		ResponseEntity<Object> response = userController.registerUser(user);

		// Then
		assertNotNull(response);
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
		assertNotNull(response.getBody());

		// 
	}

	@Test
	void testLoginUser_Success() throws InvalidCredentialException {
		// Given
		AuthDto authDto = new AuthDto("john.doe@example.com", "password");
		String token = "mockedToken";

		when(encoder.encode(authDto.getPassword())).thenReturn("encodedPassword");
		when(userService.login(any(AuthDto.class))).thenReturn(token);

		// When
		ResponseEntity<Object> response = userController.loginUser(authDto);

		// Then
		assertNotNull(response);
		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertNotNull(response.getBody());

		// 
	}


}
