package com.login.service;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.login.model.User;
import com.login.repository.UserRepository;
import com.login.service.CustomUserDetails;
import com.login.service.CustomUserDetailsService;

public class CustomUserDetailsTest {

    private CustomUserDetailsService customUserDetailsService;
    private UserRepository userRepository;

    @BeforeEach
    public void setup() {
        userRepository = mock(UserRepository.class);
        customUserDetailsService = new CustomUserDetailsService(userRepository);
    }

    @Test
    void testLoadUserByUsername_Success() {
        // Given
        String username = "test@example.com";
        User user = new User();
        user.setEmail(username);
        user.setPassword("password"); // Assuming password retrieval is handled elsewhere

        // Mock repository method
        when(userRepository.findByEmail(username)).thenReturn(user);

        // When
        CustomUserDetails userDetails = (CustomUserDetails) customUserDetailsService.loadUserByUsername(username);

        // Then
        assertNotNull(userDetails);
        assertEquals(username, userDetails.getUsername());
    }

    @Test
    void testLoadUserByUsername_UserNotFound() {
        // Given
        String username = "nonexistent@example.com";

        // Mock repository method to return null
        when(userRepository.findByEmail(username)).thenReturn(null);

        // When / Then
        UsernameNotFoundException exception = assertThrows(
                UsernameNotFoundException.class,
                () -> customUserDetailsService.loadUserByUsername(username)
        );
        assertEquals("Email Not Found " + username, exception.getMessage());
    }
}
